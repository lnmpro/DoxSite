new Vue({
    el: '.card-bg',
    data: {
      welcome: ', welcome back!',
      created: "Your ccount was created: ",
      info: 'Number of your posts: ',
      stars: '10',
    }
})

function searchFunction() {
  var input;
  var filter; 
  var ul; 
  var li;
  var a;
  var i;
  var txtValue;

  input = document.getElementById("search-input");
  filter = input.value.toUpperCase();

  ul = document.getElementById("dox-list-box");
  li = ul.getElementsByTagName("li");

  for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByTagName("a")[0];
      txtValue = a.textContent || a.innerText;

      if (txtValue.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
      } else {
          li[i].style.display = "none";
      }
  }
}

function mobileNavbar() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}

function addPasteInfo() {
  var x = document.getElementById("doxUploadAreaInfo");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}